$ErrorActionPreference = "Stop"
$scriptPath = $MyInvocation.MyCommand.Path
$root = Split-Path -Parent $scriptPath
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process powershell.exe -Verb RunAs -ArgumentList @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$scriptPath`"")
    exit
}
Get-Process led_host_app,led_host_tray -ErrorAction SilentlyContinue | Stop-Process -Force
& (Join-Path $root "windows-host\driver\idd-virtual-display\scripts\remove-virtual-display.ps1") -RepoRoot $root
& (Join-Path $root "windows-host\driver\idd-virtual-display\scripts\uninstall-driver.ps1")
Remove-Item (Join-Path ([Environment]::GetFolderPath('Startup')) "LAN Extended Display Host.lnk") -Force -ErrorAction SilentlyContinue
Write-Host "LAN Extended Display Windows host uninstalled."
