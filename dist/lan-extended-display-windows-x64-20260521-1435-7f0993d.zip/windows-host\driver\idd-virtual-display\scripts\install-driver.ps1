param(
    [string]$RepoRoot = (Resolve-Path "$PSScriptRoot\..\..\..\..").Path,
    [string]$BuildDir = "build-idd",
    [string]$WdkRoot = "F:\Windows Kits\10",
    [string]$WdkVersion = "10.0.26100.0"
)
$ErrorActionPreference = "Stop"
$packagePath = Join-Path (Join-Path $RepoRoot $BuildDir) "driver\idd-virtual-display"
$infPath = Join-Path $packagePath "led_idd.inf"
if (-not (Test-Path $infPath)) { throw "Driver INF not found: $infPath" }
$devcon = Join-Path $RepoRoot "tools\devcon.exe"
if (-not (Test-Path $devcon)) { $devcon = Join-Path $WdkRoot "Tools\$WdkVersion\x64\devcon.exe" }
if (-not (Test-Path $devcon)) { throw "devcon.exe not found. Put it in tools\devcon.exe or install WDK." }
pnputil /add-driver $infPath
if ($LASTEXITCODE -ne 0) { throw "pnputil add-driver failed with exit code $LASTEXITCODE" }
& $devcon install $infPath "Root\LedIdd"
if ($LASTEXITCODE -ne 0) { throw "devcon install failed with exit code $LASTEXITCODE" }
Write-Host "LED IddCx virtual display driver installed."
