param(
    [switch]$NoStartup,
    [switch]$NoStartTray
)
$ErrorActionPreference = "Stop"
$scriptPath = $MyInvocation.MyCommand.Path
$root = Split-Path -Parent $scriptPath
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process powershell.exe -Verb RunAs -ArgumentList @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$scriptPath`"")
    exit
}
$tray = Join-Path $root "build\windows-host\Release\led_host_tray.exe"
if (-not (Test-Path $tray)) { throw "Tray executable not found: $tray" }
& (Join-Path $root "windows-host\driver\idd-virtual-display\scripts\install-driver.ps1") -RepoRoot $root
$rules=@(
  @{Name='LAN Extended Display Discovery';Protocol='UDP';Port='17659'},
  @{Name='LAN Extended Display Control';Protocol='TCP';Port='17660'},
  @{Name='LAN Extended Display Video';Protocol='UDP';Port='17670'},
  @{Name='LAN Extended Display Input';Protocol='UDP';Port='17691'},
  @{Name='LAN Extended Display Telemetry';Protocol='UDP';Port='17692'}
)
foreach($rule in $rules){
  Get-NetFirewallRule -DisplayName $rule.Name -ErrorAction SilentlyContinue | Remove-NetFirewallRule
  New-NetFirewallRule -DisplayName $rule.Name -Direction Inbound -Action Allow -Profile Any -Protocol $rule.Protocol -LocalPort $rule.Port | Out-Null
}
if (-not $NoStartup) {
    $startup = [Environment]::GetFolderPath('Startup')
    $shortcut = Join-Path $startup "LAN Extended Display Host.lnk"
    $shell = New-Object -ComObject WScript.Shell
    $link = $shell.CreateShortcut($shortcut)
    $link.TargetPath = $tray
    $link.WorkingDirectory = Split-Path -Parent $tray
    $link.Save()
}
if (-not $NoStartTray) {
    Get-Process led_host_tray -ErrorAction SilentlyContinue | Stop-Process -Force
    Start-Process -FilePath $tray -WorkingDirectory (Split-Path -Parent $tray)
}
Write-Host "LAN Extended Display Windows host installed."
Write-Host "Tray: $tray"
