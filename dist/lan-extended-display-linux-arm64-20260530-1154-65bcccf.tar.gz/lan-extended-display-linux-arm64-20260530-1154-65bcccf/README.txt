LAN Extended Display Linux Client ARM64
Commit: 65bcccf

Install:
  tar -xzf lan-extended-display-linux-arm64-20260530-1154-65bcccf.tar.gz
  cd lan-extended-display-linux-arm64-20260530-1154-65bcccf
  ./install.sh

Optional default Windows host IP:
  ./install.sh 10.168.20.134

Runtime requirements:
  - X11 desktop session with DISPLAY=:0 and ~/.Xauthority
  - python3
  - GTK/AppIndicator packages for tray icon if your desktop supports it
  - libjpeg-turbo, X11, GL/GStreamer libraries already used by the current client build

Check status:
  systemctl --user status lan-extended-display-client.service
  journalctl --user -u lan-extended-display-client.service -f

Uninstall:
  ./uninstall.sh
