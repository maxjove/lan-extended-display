LAN Extended Display Linux Client ARM64
Commit: 50a2949

Install:
  tar -xzf lan-extended-display-linux-arm64-20260521-1637-50a2949.tar.gz
  cd lan-extended-display-linux-arm64-20260521-1637-50a2949
  ./install.sh

Optional default Windows host IP:
  ./install.sh 10.168.20.196

Runtime requirements:
  - X11 desktop session with DISPLAY=:0 and ~/.Xauthority
  - python3
  - GTK/AppIndicator packages for tray icon if your desktop supports it
  - libjpeg-turbo, X11, GL/GStreamer libraries already used by the current client build

Check status:
  systemctl --user status lan-extended-display-client.service
  journalctl --user -u lan-extended-display-client.service -f

Uninstall:
  ./uninstall.sh
