#!/usr/bin/env bash
set -euo pipefail
HOST_IP="${1:-}"
INSTALL_DIR="${INSTALL_DIR:-$HOME/lan-extended-display}"
SERVICE_DIR="$HOME/.config/systemd/user"
SERVICE_FILE="$SERVICE_DIR/lan-extended-display-client.service"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "$INSTALL_DIR" "$SERVICE_DIR"
install -m 0755 "$SCRIPT_DIR/led_client_app" "$INSTALL_DIR/led_client_app"
install -m 0755 "$SCRIPT_DIR/led_client_tray.py" "$INSTALL_DIR/led_client_tray.py"
EXEC_COMMAND="/usr/bin/python3 \"$INSTALL_DIR/led_client_tray.py\" --client-bin \"$INSTALL_DIR/led_client_app\""
if [[ -n "$HOST_IP" ]]; then
  EXEC_COMMAND="$EXEC_COMMAND --default-host \"$HOST_IP\""
fi
cat > "$SERVICE_FILE" <<SERVICE
[Unit]
Description=LAN Extended Display Linux client tray
After=graphical-session.target network-online.target
Wants=network-online.target

[Service]
Type=simple
Environment=DISPLAY=:0
Environment=XAUTHORITY=%h/.Xauthority
ExecStart=${EXEC_COMMAND}
Restart=on-failure
RestartSec=3

[Install]
WantedBy=default.target
SERVICE
systemctl --user daemon-reload
systemctl --user enable lan-extended-display-client.service >/dev/null
systemctl --user restart lan-extended-display-client.service
if command -v loginctl >/dev/null 2>&1; then
  loginctl enable-linger "$USER" >/dev/null 2>&1 || true
fi
echo "Installed LAN Extended Display Linux client."
echo "Install dir: $INSTALL_DIR"
echo "Status: systemctl --user status lan-extended-display-client.service"
