#!/usr/bin/env bash
set -euo pipefail
INSTALL_DIR="${INSTALL_DIR:-$HOME/lan-extended-display}"
SERVICE_FILE="$HOME/.config/systemd/user/lan-extended-display-client.service"
systemctl --user disable --now lan-extended-display-client.service >/dev/null 2>&1 || true
rm -f "$SERVICE_FILE"
systemctl --user daemon-reload
rm -f "$INSTALL_DIR/led_client_app" "$INSTALL_DIR/led_client_tray.py"
rmdir "$INSTALL_DIR" >/dev/null 2>&1 || true
echo "Removed LAN Extended Display Linux client."
