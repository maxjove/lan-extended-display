LAN Extended Display Windows Host x64
Commit: 65bcccf

Install:
  1. Extract this zip to a stable local directory.
  2. Right click install-windows.ps1 and run with PowerShell, or run:
     powershell -ExecutionPolicy Bypass -File .\install-windows.ps1

What it installs:
  - LED IddCx virtual display driver
  - Windows firewall rules for LAN discovery/stream/input
  - Startup shortcut for led_host_tray.exe unless -NoStartup is passed

Run manually:
  .\build\windows-host\Release\led_host_tray.exe

Uninstall:
  powershell -ExecutionPolicy Bypass -File .\uninstall-windows.ps1
